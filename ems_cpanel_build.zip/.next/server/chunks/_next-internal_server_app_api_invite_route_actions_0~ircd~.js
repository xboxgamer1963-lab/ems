module.exports=[34204,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invite_route_actions_0~ircd~.js.map