module.exports=[95224,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_scheduling_page_actions_0def69y.js.map