module.exports=[62998,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_performance_page_actions_0h_4ag_.js.map