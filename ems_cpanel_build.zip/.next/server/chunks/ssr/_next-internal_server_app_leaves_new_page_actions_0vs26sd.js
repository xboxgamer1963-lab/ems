module.exports=[93206,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_leaves_new_page_actions_0vs26sd.js.map