module.exports=[68533,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hr-managers_new_page_actions_0e3g_la.js.map