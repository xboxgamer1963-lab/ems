var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invite/route.js")
R.c("server/chunks/[root-of-the-server]__0pvqc9z._.js")
R.c("server/chunks/[root-of-the-server]__0os6qlg._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_invite_route_actions_0~ircd~.js")
R.m(49313)
module.exports=R.m(49313).exports
